import React from 'react';
import {View, Text, Image, ScrollView, TextInput} from 'react-native';

const App = () => {
  return (
    <ScrollView
    style={{
      justifyContent: 'center',
      alignItems: 'center',
    }}>
    <View
    style={{
      justifyContent: 'center',
      alignItems: 'center',
    }}>
     <Text>Reinalyn Diaded</Text>
      <Text>IT-302</Text>
       <Image
       source={{
        uri: 'https://th.bing.com/th/id/OIP.Tkm3XUGmmmfpjVAdsk7PbQHaHp?rs=1&pid=ImgDetMain=0',
    }}
    style={{width: 200, height:200}}
/>
</View>
<TextInput
 style={{
   height:40,
   borderColor: 'gray',
   borderWidth: 1,
 }}
 defaultValue="You Can type in me"
/>
</ScrollView>
 ); 
};

export default App;